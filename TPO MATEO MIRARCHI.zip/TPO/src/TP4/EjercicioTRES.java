package TP4;

import API.ABBTDA;
import API.ConjuntoTDA;
import IMPL.ABBDinamico;
import IMPL.ConjuntoEstatico;
import UTIL.OperacionArbol;
import UTIL.OperacionConjunto;

public class EjercicioTRES {

	public static void main(String[] args) {
		
		//PUNTO A
		
		ABBTDA arbol1 = new ABBDinamico();
		arbol1.inicializarArbol();
		
		arbol1.agregar(9);
		arbol1.agregar(7);
		arbol1.agregar(8);
		arbol1.agregar(6);
		arbol1.agregar(3);
		arbol1.agregar(5);
		arbol1.agregar(123);
		arbol1.agregar(552);
		arbol1.agregar(9999);
		
		OperacionArbol operacion = new OperacionArbol();
		
		boolean pertenece = operacion.pertenece(8, arbol1);
		
		System.out.println("EJ A");
		if(pertenece == true) {
			System.out.println("El elemento pertenece al arbol");
		}else {
			System.out.println("El elemento NO pertenece al arbol");
		}
		
		//PUNTO B
		
		ABBTDA arbol2 = new ABBDinamico();
		arbol2.inicializarArbol();
		
		arbol2.agregar(9);
		arbol2.agregar(7);
		arbol2.agregar(8);
		arbol2.agregar(6);
		arbol2.agregar(3);
		arbol2.agregar(5);
		arbol2.agregar(123);
		arbol2.agregar(552);
		arbol2.agregar(9999);
		
		boolean esHoja = operacion.esHoja(9999, arbol2);
		
		System.out.println("EJ B");
		if(esHoja == true) {
			System.out.println("El elemento es hoja");
		}else {
			System.out.println("El elemento NO es hoja");
		}
		
		//PUNTO C
		
		ABBTDA arbol3 = new ABBDinamico();
		arbol3.inicializarArbol();
		
		arbol3.agregar(9);
		arbol3.agregar(7);
		arbol3.agregar(8);
		arbol3.agregar(6);
		arbol3.agregar(3);
		arbol3.agregar(5);
		arbol3.agregar(123);
		arbol3.agregar(552);
		arbol3.agregar(9999);
		
		System.out.println("EJ C");
		System.out.println("La profundidad del elemento es: " + operacion.profundidad(9999, arbol3));
		
		//PUNTO D
		
		ABBTDA arbol4 = new ABBDinamico();
		arbol4.inicializarArbol();
		
		arbol4.agregar(9);
		arbol4.agregar(7);
		arbol4.agregar(8);
		arbol4.agregar(6);
		arbol4.agregar(3);
		arbol4.agregar(5);
		arbol4.agregar(123);
		arbol4.agregar(552);
		arbol4.agregar(9999);
		
		System.out.println("EJ D");
		System.out.println("El elemento menor del arbol es: " + operacion.menor(arbol4));
		
		//PUNTO E
		
		ABBTDA arbol5  = new ABBDinamico();
		arbol5.inicializarArbol();
		
		arbol5.agregar(9);
		arbol5.agregar(7);
		arbol5.agregar(8);
		arbol5.agregar(6);
		arbol5.agregar(3);
		arbol5.agregar(5);
		arbol5.agregar(123);
		arbol5.agregar(552);
		arbol5.agregar(9999);
		
		System.out.println("EJ E");
		System.out.println("La cantidad de elementos del arbol es: " + operacion.cantElementos(arbol5));
		
		//PUNTO F
		
		ABBTDA arbol6 = new ABBDinamico();
		arbol6.inicializarArbol();
		
		arbol6.agregar(9);
		arbol6.agregar(7);
		arbol6.agregar(8);
		arbol6.agregar(6);
		arbol6.agregar(3);
		arbol6.agregar(5);
		arbol6.agregar(123);
		arbol6.agregar(552);
		arbol6.agregar(9999);
		
		System.out.println("EJ F");
		System.out.println("La suma de los elementos del arbol es: " + operacion.suma(arbol6));
		
		//PUNTO G
		
		ABBTDA arbol7 = new ABBDinamico();
		arbol7.inicializarArbol();
		
		arbol7.agregar(9);
		arbol7.agregar(7);
		arbol7.agregar(8);
		arbol7.agregar(6);
		arbol7.agregar(3);
		arbol7.agregar(5);
		arbol7.agregar(123);
		arbol7.agregar(552);
		arbol7.agregar(9999);
		
		System.out.println("EJ G");
		System.out.println("La cantidad de hojas del arbol es: " + operacion.cantHojas(arbol7));
		
		//PUNTO H
		
		ABBTDA arbol8 = new ABBDinamico();
		arbol8.inicializarArbol();
		
		arbol8.agregar(9);
		arbol8.agregar(7);
		arbol8.agregar(8);
		arbol8.agregar(6);
		arbol8.agregar(3);
		arbol8.agregar(5);
		arbol8.agregar(123);
		arbol8.agregar(552);
		arbol8.agregar(9999);
		
		System.out.println("EJ H");
		System.out.println("La altura del arbol es: " + operacion.altura(arbol8));
		
		//PUNTO I
		
		ABBTDA arbol9 = new ABBDinamico();
		arbol9.inicializarArbol();
		
		ABBTDA arbol10 = new ABBDinamico();
		arbol10.inicializarArbol();
		
		arbol9.agregar(9);
		arbol9.agregar(7);
		arbol9.agregar(8);
		arbol9.agregar(6);
		arbol9.agregar(3);
		arbol9.agregar(5);
		arbol9.agregar(123);
		arbol9.agregar(552);
		arbol9.agregar(9999);
		
		arbol10.agregar(9);
		arbol10.agregar(7);
		arbol10.agregar(8);
		arbol10.agregar(6);
		arbol10.agregar(3);
		arbol10.agregar(5);
		arbol10.agregar(123);
		arbol10.agregar(552);
		arbol10.agregar(9999);
		arbol10.agregar(1155);
		
		boolean mismaForma = operacion.mismaForma(arbol9, arbol10);
		
		System.out.println("EJ I");
		if(mismaForma == true) {
			System.out.println("Los arboles tienen la misma forma");
		}else {
			System.out.println("Los arboles NO tienen la misma forma");
		}
		
		//PUNTO J
		
		ABBTDA arbol11 = new ABBDinamico();
		arbol9.inicializarArbol();
		
		ABBTDA arbol12 = new ABBDinamico();
		arbol10.inicializarArbol();
		
		arbol11.agregar(9);
		arbol11.agregar(7);
		arbol11.agregar(8);
		arbol11.agregar(6);
		arbol11.agregar(3);
		arbol11.agregar(5);
		arbol11.agregar(123);
		arbol11.agregar(552);
		arbol11.agregar(9999);
		
		arbol12.agregar(9);
		arbol12.agregar(7);
		arbol12.agregar(8);
		arbol12.agregar(6);
		arbol12.agregar(3);
		arbol12.agregar(5);
		arbol12.agregar(123);
		arbol12.agregar(552);
		arbol12.agregar(9999);
		
		boolean sonIguales = operacion.sonIguales(arbol11, arbol12);
		
		System.out.println("EJ J");
		if(sonIguales == true) {
			System.out.println("Los arboles son iguales");
		}else {
			System.out.println("Los arboles NO son iguales");
		}
		
		//PUNTO K
		
		ABBTDA arbol13 = new ABBDinamico();;
		arbol13.inicializarArbol();
		
		arbol13.agregar(9);
		arbol13.agregar(7);
		arbol13.agregar(8);
		arbol13.agregar(6);
		arbol13.agregar(3);
		arbol13.agregar(5);
		arbol13.agregar(123);
		arbol13.agregar(552);
		arbol13.agregar(9999);
		
		System.out.println("EJ K");
		System.out.println("La cantidad de elementos de ese nivel es: " + operacion.contPorNivel(arbol13, 2));
		
		//PUNTO L
		
		ABBTDA arbol14 = new ABBDinamico();
		arbol14.inicializarArbol();
		
		arbol14.agregar(9);
		arbol14.agregar(7);
		arbol14.agregar(8);
		arbol14.agregar(6);
		arbol14.agregar(3);
		arbol14.agregar(5);
		arbol14.agregar(123);
		arbol14.agregar(552);
		arbol14.agregar(9999);
		
		System.out.println("EJ L");
		System.out.println("In order: ");
		operacion.mostrarInOrder(arbol14);
		System.out.println("");
		System.out.println("Pre order: ");
		operacion.mostrarPreOrder(arbol14);
		System.out.println("");
		System.out.println("Post order: ");
		operacion.mostrarPostOrder(arbol14);
		
		//PUNTO M
		
		ABBTDA arbol15 = new ABBDinamico();
		arbol15.inicializarArbol();
		
		ConjuntoTDA conjunto = new ConjuntoEstatico();
		conjunto.inicializarConjunto();
		
		arbol15.agregar(9);
		arbol15.agregar(7);
		arbol15.agregar(8);
		arbol15.agregar(6);
		arbol15.agregar(3);
		arbol15.agregar(5);
		arbol15.agregar(123);
		arbol15.agregar(552);
		arbol15.agregar(9999);
		
		operacion.conjuntoMayores(arbol15, 10, conjunto);
		
		OperacionConjunto operacionConjuto = new OperacionConjunto();
		
		System.out.println("");
		System.out.println("EJ M");
		operacionConjuto.mostrarConjunto(conjunto);
		
		//PUNTO N
		
		ABBTDA arbol16 = new ABBDinamico();
		arbol16.inicializarArbol();
		
		arbol16.agregar(9);
		arbol16.agregar(7);
		arbol16.agregar(8);
		arbol16.agregar(6);
		arbol16.agregar(3);
		arbol16.agregar(5);
		arbol16.agregar(123);
		arbol16.agregar(552);
		arbol16.agregar(9999);
		
		System.out.println("EJ N");
		System.out.println("El anterior del numero seleccionado es: " + operacion.anterior(arbol16, 6));
		
	}

}
