package TP3;

import java.util.Scanner;

import API.ColaPrioridadTDA;
import IMPL.ColaPrioridadEstatica;
import IMPL.ConjuntoEstatico;
import IMPL.DicMultipleEstatico;
import UTIL.OperacionColaPrioridad;
import UTIL.OperacionDiccionario;
import API.DiccionarioMultipleTDA;
import API.ConjuntoTDA;

public class EjercicioCUATRO {

	public static void main(String[] args) {
		
		//PUNTO A
		
		OperacionColaPrioridad operacion = new OperacionColaPrioridad();
        OperacionDiccionario operacionDiccionario = new OperacionDiccionario();
        Scanner scanner = new Scanner(System.in);

        ColaPrioridadTDA colaPrioridad1 = new ColaPrioridadEstatica();
        DiccionarioMultipleTDA diccionario = new DicMultipleEstatico();
        ConjuntoTDA conjunto = new ConjuntoEstatico();
        colaPrioridad1.inicializarCola();
        diccionario.inicializarDiccionario();
        conjunto.inicializarConjunto();

        operacion.llenarConPrioridad(colaPrioridad1,scanner);
        operacion.GenerarDiccionarioMultiple(colaPrioridad1,conjunto,diccionario);
        
        System.out.println("EJ A");
        operacionDiccionario.imprimir(diccionario);

	}

}
