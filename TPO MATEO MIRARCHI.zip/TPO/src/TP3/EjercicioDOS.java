package TP3;

import java.util.Scanner;
import API.ColaTDA;
import IMPL.ColaEstatica;
import IMPL.ConjuntoEstatico;
import UTIL.OperacionCola;
import UTIL.OperacionConjunto;
import API.ConjuntoTDA;

public class EjercicioDOS {

	public static void main(String[] args) {

        //PUNTO A
		
		OperacionCola operacionCola = new OperacionCola();
        OperacionConjunto operacionConjunto = new OperacionConjunto();
        Scanner scanner = new Scanner(System.in);
        
        ColaTDA colaSinRepeticion = new ColaEstatica();
        colaSinRepeticion.inicializarCola();
        
        operacionCola.llenar(colaSinRepeticion,scanner);
        operacionCola.copiarSinRepetidos(colaSinRepeticion);
        
        System.out.println("EJ A");
        System.out.println("Cola sin repetidos: ");
        operacionCola.mostrar(colaSinRepeticion);

        //PUNTO B
        
        ColaTDA colaMitad = new ColaEstatica();
        ColaTDA colaMitad1 = new ColaEstatica();
        ColaTDA colaMitad2 = new ColaEstatica();
        colaMitad.inicializarCola();
        colaMitad1.inicializarCola();
        colaMitad2.inicializarCola();

        operacionCola.llenar(colaMitad,scanner);
        operacionCola.dividirMitad(colaMitad,colaMitad1,colaMitad2);
        
        System.out.println("EJ B");
        System.out.println("Mitad 1: ");
        operacionCola.mostrar(colaMitad1);
        System.out.println("Mitad 2: ");
        operacionCola.mostrar(colaMitad2);


        //PUNTO C
        
        ColaTDA colaSoloRepeticion = new ColaEstatica();
        ConjuntoTDA conjuntoRepetidos = new ConjuntoEstatico();
        colaSoloRepeticion.inicializarCola();
        conjuntoRepetidos.inicializarConjunto();

        operacionCola.llenar(colaSoloRepeticion,scanner);
        operacionCola.copiarSoloRepetidos(colaSoloRepeticion, conjuntoRepetidos);
        
        System.out.println("EJ C");
        System.out.println("Cola solo de repetidos: ");
        operacionConjunto.imprimir(conjuntoRepetidos);


	}

}
