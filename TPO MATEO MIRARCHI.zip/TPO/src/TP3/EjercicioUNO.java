package TP3;

import java.util.Scanner;

import API.ConjuntoTDA;
import API.PilaTDA;
import IMPL.ConjuntoEstatico;
import IMPL.PilaEstatica;
import UTIL.OperacionCola;
import UTIL.OperacionConjunto;
import UTIL.OperacionPila;

public class EjercicioUNO {

	public static void main(String[] args) {
		
		//PUNTO A (EN LA ULTIMA PRUEBA QUE HICE ME DEJO DE FUNCIONAR)
		/*
		PilaTDA pila1 = new PilaEstatica();
		pila1.inicializarPila();
		
		operaciones.llenar(pila1, scanner);
		
		boolean resultadoCapicua = operaciones.esCapicua(pila1);
		
		System.out.println("EJ A");
		if(resultadoCapicua == true) {
			System.out.println("La pila es capicua");
		}else {
			System.out.println("La pila NO es capicua");
		}
		*/
		//PUNTO B
		
		OperacionPila operaciones = new OperacionPila();
		Scanner scanner = new Scanner(System.in);
		
		PilaTDA pila2 = new PilaEstatica();
		pila2.inicializarPila();
		
		operaciones.llenar(pila2, scanner);
		
		PilaTDA pilaResultado = operaciones.eliminarRepetidos(pila2);
		
		operaciones.mostrarPila(pilaResultado);
		
		//PUNTO C
		
		PilaTDA pila3 = new PilaEstatica();
		pila3.inicializarPila();
		
		PilaTDA pilaMitad1 = new PilaEstatica();
		pilaMitad1.inicializarPila();
		
		PilaTDA pilaMitad2 = new PilaEstatica();
		pilaMitad2.inicializarPila();
		
		operaciones.llenar(pila3, scanner);
		
		operaciones.repartirPilas(pila3, pilaMitad1, pilaMitad2);
		
		operaciones.mostrarPila(pilaMitad1);
		operaciones.mostrarPila(pilaMitad2);
		
		//PUNTO D
		
		PilaTDA pila4 = new PilaEstatica();
		pila4.inicializarPila();
		
		ConjuntoTDA conjunto = new ConjuntoEstatico();
		conjunto.inicializarConjunto();
		
		operaciones.llenar(pila4, scanner);
		
		operaciones.rellenarConjunto(pila4, conjunto);
		
		OperacionConjunto opera = new OperacionConjunto();
		opera.mostrarConjunto(conjunto);

	}

}
