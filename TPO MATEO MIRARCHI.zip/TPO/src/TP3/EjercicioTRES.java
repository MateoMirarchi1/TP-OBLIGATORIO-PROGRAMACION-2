package TP3;

import java.util.Scanner;

import UTIL.OperacionCola;
import UTIL.OperacionConjunto;
import UTIL.OperacionPila;
import API.ConjuntoTDA;
import IMPL.ColaEstatica;
import IMPL.ConjuntoEstatico;
import IMPL.PilaEstatica;
import API.PilaTDA;
import API.ColaTDA;

public class EjercicioTRES {

	public static void main(String[] args) {
		
		OperacionConjunto operacion = new OperacionConjunto();
        OperacionCola operacionCola = new OperacionCola();
        OperacionPila operacionPila = new OperacionPila();
        Scanner scanner = new Scanner(System.in);
        
        //PUNTO B
        
        ConjuntoTDA conjuntoSinOperaciones1 = new ConjuntoEstatico();
        ConjuntoTDA conjuntoSinOperaciones2 = new ConjuntoEstatico();
        conjuntoSinOperaciones1.inicializarConjunto();
        conjuntoSinOperaciones2.inicializarConjunto();

        conjuntoSinOperaciones1.agregar(3);
        conjuntoSinOperaciones1.agregar(1);
        conjuntoSinOperaciones1.agregar(10);
        conjuntoSinOperaciones1.agregar(7);
        conjuntoSinOperaciones2.agregar(3);
        conjuntoSinOperaciones2.agregar(2);
        conjuntoSinOperaciones2.agregar(6);
        conjuntoSinOperaciones2.agregar(5);

        ConjuntoTDA diferencia = operacion.diferenciaSimetricaSinOperaciones(conjuntoSinOperaciones1, conjuntoSinOperaciones2);
        
        System.out.println("EJ B");
        operacion.imprimir(diferencia);

        //PUNTO C
        
        ConjuntoTDA conjuntoConOperaciones1 = new ConjuntoEstatico();
        ConjuntoTDA conjuntoConOperaciones2 = new ConjuntoEstatico();
        conjuntoConOperaciones1.inicializarConjunto();
        conjuntoConOperaciones2.inicializarConjunto();

        conjuntoConOperaciones1.agregar(6);
        conjuntoConOperaciones1.agregar(9);
        conjuntoConOperaciones1.agregar(2);
        conjuntoConOperaciones1.agregar(7);
        conjuntoConOperaciones2.agregar(10);
        conjuntoConOperaciones2.agregar(4);
        conjuntoConOperaciones2.agregar(11);
        conjuntoConOperaciones2.agregar(5);

        ConjuntoTDA diferencia1 = operacion.diferenciaSimetricaConOperaciones(conjuntoConOperaciones1, conjuntoConOperaciones2);
        System.out.println("EJ C");
        operacion.imprimir(diferencia1);

        //PUNTO D
        
        ConjuntoTDA conjuntoIgual = new ConjuntoEstatico();
        ConjuntoTDA conjuntoIgual1 = new ConjuntoEstatico();
        conjuntoIgual.inicializarConjunto();
        conjuntoIgual1.inicializarConjunto();

        conjuntoIgual.agregar(1);
        conjuntoIgual.agregar(2);
        conjuntoIgual1.agregar(1);
        conjuntoIgual1.agregar(2);

        Boolean iguales = operacion.sonIguales(conjuntoIgual,conjuntoIgual1);
        System.out.println("EJ D");
        System.out.println("Son iguales?: " + iguales);

        //PUTNO E
        
        ConjuntoTDA contarConjunto = new ConjuntoEstatico();
        contarConjunto.inicializarConjunto();
        
        contarConjunto.agregar(1);
        contarConjunto.agregar(2);
        contarConjunto.agregar(3);
        contarConjunto.agregar(4);

        int cantidad = operacion.cardinalidad(contarConjunto);
        System.out.println("EJ E");
        System.out.println("El conjunto tiene " + cantidad + " elementos");

        //PUNTO F
        
        PilaTDA pila = new PilaEstatica();
        ColaTDA cola = new ColaEstatica();
        pila.inicializarPila();
        cola.inicializarCola();

        operacionPila.llenar(pila,scanner);
        operacionCola.llenar(cola,scanner);

        ConjuntoTDA elementosEnAmbos = operacion.elementosComunes(pila,cola);
        
        System.out.println("EJ F");
        System.out.println("Los elementos que estan en la pila y la cola son: ");
        operacion.imprimir(elementosEnAmbos);

        //G
        System.out.println("Ejercicio G");
        PilaTDA pila1 = new PilaEstatica();
        ColaTDA cola1 = new ColaEstatica();
        pila1.inicializarPila();
        cola1.inicializarCola();

        operacionPila.llenar(pila1,scanner);
        operacionCola.llenar(cola1,scanner);

        boolean mismosElementos = operacion.mismosElementos(pila1,cola1);
        System.out.println("EJ G");
        System.out.println("Ambos tienen los mismos elementos?: " + mismosElementos);

	}

}
