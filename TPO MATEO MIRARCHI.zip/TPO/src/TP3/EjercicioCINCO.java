package TP3;

import UTIL.OperacionDiccionario;
import API.DiccionarioMultipleTDA;
import IMPL.DicMultipleEstatico;

public class EjercicioCINCO {

	public static void main(String[] args) {

        //PUNTO 5.1 A

		OperacionDiccionario operacionDiccionario = new OperacionDiccionario();
        DiccionarioMultipleTDA diccionario1 = new DicMultipleEstatico();
        diccionario1.inicializarDiccionario();
        DiccionarioMultipleTDA diccionario2 = new DicMultipleEstatico();
        diccionario2.inicializarDiccionario();

        diccionario1.agregar(1,7);
        diccionario1.agregar(9,9);
        diccionario1.agregar(6,3);
        diccionario2.agregar(4,9);
        diccionario2.agregar(1,5);
        diccionario2.agregar(3,7);

        DiccionarioMultipleTDA diccionarioUnido = operacionDiccionario.union(diccionario1,diccionario2);
        
        System.out.println("EJ 5.1 A");
        operacionDiccionario.imprimir(diccionarioUnido);

        //PUNTO 5.1 B
        System.out.println();
        
        DiccionarioMultipleTDA diccionario3 = new DicMultipleEstatico();
        DiccionarioMultipleTDA diccionario4 = new DicMultipleEstatico();
        diccionario3.inicializarDiccionario();
        diccionario4.inicializarDiccionario();

        diccionario3.agregar(1,3);
        diccionario3.agregar(1,4);
        diccionario3.agregar(1,3);
        diccionario3.agregar(7,1);
        diccionario3.agregar(2,5);
        diccionario4.agregar(1,3);
        diccionario4.agregar(1,9);
        diccionario4.agregar(9,2);
        diccionario4.agregar(8,8);

        DiccionarioMultipleTDA interseccion = operacionDiccionario.interseccionElementosPorClave(diccionario3,diccionario4);
        
        System.out.println("EJ 5.1 B");
        operacionDiccionario.imprimir(interseccion);

        //PUNTO 5.1 C
        System.out.println();
        
        DiccionarioMultipleTDA diccionario5 = new DicMultipleEstatico();
        DiccionarioMultipleTDA diccionario6 = new DicMultipleEstatico();
        diccionario5.inicializarDiccionario();
        diccionario6.inicializarDiccionario();
        
        diccionario5.agregar(8,3);
        diccionario5.agregar(4,2);
        diccionario5.agregar(1,3);
        diccionario6.agregar(7,1);
        diccionario6.agregar(2,5);
        diccionario6.agregar(5,7);

        DiccionarioMultipleTDA diccionarioClavesComunes = operacionDiccionario.unionValoresCC(diccionario5,diccionario6);
        
        System.out.println("EJ 5.1 C");
        operacionDiccionario.imprimir(diccionarioClavesComunes);

        //PUNTO 5.1 D
        System.out.println();
        
        DiccionarioMultipleTDA diccionario7 = new DicMultipleEstatico();
        DiccionarioMultipleTDA diccionario8 = new DicMultipleEstatico();
        diccionario7.inicializarDiccionario();
        diccionario8.inicializarDiccionario();

        diccionario7.agregar(1,3);
        diccionario7.agregar(7,1);
        diccionario7.agregar(2,5);
        diccionario8.agregar(1,9);
        diccionario8.agregar(6,9);
        diccionario8.agregar(5,7);

        DiccionarioMultipleTDA diccionarioInter = operacionDiccionario.interseccionCYV(diccionario7,diccionario8);
        operacionDiccionario.imprimir(diccionarioInter);

        //PUNTO 5.2
        System.out.println();
        
        DiccionarioMultipleTDA diccionario = new DicMultipleEstatico();
        diccionario.inicializarDiccionario();

        diccionario.agregar(1,3);
        diccionario.agregar(7,1);
        diccionario.agregar(2,5);
        diccionario.agregar(9,9);

        System.out.println("EJ 5.2");
        operacionDiccionario.imprimir(diccionario);

	}

}
