package TP6;

import API.GrafoTDA;
import IMPL.GrafoMA;
import UTIL.OperacionGrafo;

public class EjercicioCINCO {

	public static void main(String[] args) {
		
		GrafoTDA grafo1 = new GrafoMA();
		grafo1.inicializarGrafo();
		
		grafo1.agregarVertice(1);
		grafo1.agregarVertice(2);
		grafo1.agregarVertice(3);
		grafo1.agregarVertice(4);
		grafo1.agregarVertice(5);
		grafo1.agregarVertice(6);
		grafo1.agregarArista(1, 2, 4);
		grafo1.agregarArista(1, 5, 1);
		grafo1.agregarArista(1, 3, 4);
		grafo1.agregarArista(3, 4, 4);
		
		OperacionGrafo operacion = new OperacionGrafo();
		
		int mayorCosto = operacion.mayorCosto(grafo1, 3);

		System.out.println(mayorCosto);
	}

}
