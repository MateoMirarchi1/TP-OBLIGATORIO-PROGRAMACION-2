package TP6;

import API.ConjuntoTDA;
import API.GrafoTDA;
import IMPL.ConjuntoEstatico;
import IMPL.GrafoMA;
import UTIL.OperacionConjunto;
import UTIL.OperacionGrafo;

public class EjercicioSEIS {

	public static void main(String[] args) {
		
		GrafoTDA grafo1 = new GrafoMA();
		grafo1.inicializarGrafo();
		
		grafo1.agregarVertice(1);
		grafo1.agregarVertice(2);
		grafo1.agregarVertice(3);
		grafo1.agregarVertice(4);
		grafo1.agregarVertice(5);
		grafo1.agregarVertice(6);
		grafo1.agregarArista(1, 2, 4);
		grafo1.agregarArista(1, 5, 1);
		grafo1.agregarArista(1, 3, 4);
		grafo1.agregarArista(3, 4, 4);
		
		OperacionGrafo operacion = new OperacionGrafo();
		OperacionConjunto operacionConj = new OperacionConjunto();
		
		ConjuntoTDA conjunto1 = new ConjuntoEstatico();
		conjunto1.inicializarConjunto();
		
		conjunto1 = operacion.predecesor(grafo1, 5);
		
		operacionConj.mostrarConjunto(conjunto1);

	}

}
