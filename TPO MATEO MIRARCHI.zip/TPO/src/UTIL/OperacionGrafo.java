package UTIL;

import API.ConjuntoTDA;
import API.GrafoTDA;
import IMPL.ConjuntoEstatico;

public class OperacionGrafo {
	
	public static ConjuntoTDA adyacentesDobles(GrafoTDA grafo, int v) {
		ConjuntoTDA auxiliar1 = new ConjuntoEstatico();
		ConjuntoTDA auxiliar2 = new ConjuntoEstatico();
		ConjuntoTDA c = new ConjuntoEstatico();
		auxiliar1.inicializarConjunto();
		auxiliar2.inicializarConjunto();
		c.inicializarConjunto();
		auxiliar1=grafo.vertices();
		auxiliar2=grafo.vertices();
		auxiliar1.sacar(v);
		auxiliar2.sacar(v);
		int v2;
		int v3;
		while(!auxiliar1.conjuntoVacio()) {
			v2=auxiliar1.elegir();
			auxiliar2=grafo.vertices();
			auxiliar2.sacar(v);
			if (grafo.ExisteArista(v, v2)) {
				while(!auxiliar2.conjuntoVacio()) {
					v3=auxiliar2.elegir();
					if (grafo.ExisteArista(v2, v3) && v2!=v3) {
						c.agregar(v3);
					}
					auxiliar2.sacar(v3);
				}
			}
			auxiliar1.sacar(v2);
		}
		return c;

	}
	
	public static int mayorCosto(GrafoTDA grafo, int v) {
		ConjuntoTDA auxiliar = new ConjuntoEstatico();
		auxiliar.inicializarConjunto();
		auxiliar=grafo.vertices();
		int v2;
		int mayor=0;
		while (!auxiliar.conjuntoVacio()) {
			v2=auxiliar.elegir();
			if (grafo.ExisteArista(v, v2)) {
				if(grafo.pesoArista(v, v2)>mayor) {
					mayor=grafo.pesoArista(v, v2);
				}
			}
			auxiliar.sacar(v2);
		}
		return mayor;
	}
	
	public static ConjuntoTDA predecesor(GrafoTDA grafo, int v) {
		ConjuntoTDA auxiliar = new ConjuntoEstatico();
		auxiliar.inicializarConjunto();
		ConjuntoTDA c = new ConjuntoEstatico();
		c.inicializarConjunto();
		auxiliar=grafo.vertices();
		int v2;
		while (!auxiliar.conjuntoVacio()) {
			v2=auxiliar.elegir();
			if (grafo.ExisteArista(v2, v)) {
				c.agregar(v2);
			}
			auxiliar.sacar(v2);
		}
		return c;
	}
	
	public static ConjuntoTDA aislados(GrafoTDA grafo) {
		ConjuntoTDA auxiliar = new ConjuntoEstatico();
		auxiliar.inicializarConjunto();
		ConjuntoTDA c = new ConjuntoEstatico();
		c.inicializarConjunto();
		ConjuntoTDA auxiliar2 = new ConjuntoEstatico();
		auxiliar2.inicializarConjunto();
		auxiliar=grafo.vertices();
		int v;
		int v2;
		boolean EsAislado;
		while (!auxiliar.conjuntoVacio()) {
			auxiliar2=grafo.vertices();
			v=auxiliar.elegir();
			EsAislado=true;
			while(EsAislado==true && !auxiliar2.conjuntoVacio()) {
				v2=auxiliar2.elegir();
				if ((grafo.ExisteArista(v, v2) || grafo.ExisteArista(v2, v)) && (v!=v2)) {
					EsAislado = false;
				}
				auxiliar2.sacar(v2);
			}
			if (EsAislado == true) {
				c.agregar(v);
			}
			auxiliar.sacar(v);
		}
		return c;
	}
	
	public static ConjuntoTDA puentes(GrafoTDA grafo, int v, int v2) {
		ConjuntoTDA c = new ConjuntoEstatico();
		c.inicializarConjunto();
		ConjuntoTDA auxiliar = new ConjuntoEstatico();
		auxiliar.inicializarConjunto();
		auxiliar=grafo.vertices();
		int g;
		while(!auxiliar.conjuntoVacio()) {
			g=auxiliar.elegir();
			if (grafo.ExisteArista(v, g) && grafo.ExisteArista(g, v2) && v!=v2) {
				c.agregar(g);
			}
			auxiliar.sacar(g);
		}
		return c;
	}

	public static int calcularGrado(GrafoTDA grafo,int v) {
		int grado=0;
		int g;
		ConjuntoTDA aux = new ConjuntoEstatico();
		aux.inicializarConjunto();
		aux=grafo.vertices();
		while(!aux.conjuntoVacio()) {
			g=aux.elegir();
			if(grafo.ExisteArista(v, g)) {
				grado++;
			}
			if (grafo.ExisteArista(g, v)) {
				grado--;
			}
			aux.sacar(g);
		}
		return grado;
	}
}
