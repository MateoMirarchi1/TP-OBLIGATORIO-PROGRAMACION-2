package UTIL;

import API.ConjuntoTDA;
import API.DiccionarioMultipleTDA;
import API.DiccionarioSimpleTDA;
import IMPL.DicMultipleDinamico;

public class OperacionDiccionario {

    public void mostrarDiccionario(DiccionarioSimpleTDA diccionario) {
        ConjuntoTDA claves = diccionario.Claves();  

        while (!claves.conjuntoVacio()) {
            int clave = claves.elegir();  
            int valor = diccionario.Recuperar(clave);  

            System.out.println("Elemento: " + clave + " - Valor: " + valor);

            claves.sacar(clave);  
        }
    }
    
    public DiccionarioMultipleTDA union(DiccionarioMultipleTDA d1, DiccionarioMultipleTDA d2){
        ConjuntoTDA c = d2.claves();

        while (!c.conjuntoVacio()) {

            int clave = c.elegir();
            ConjuntoTDA valores = d2.recuperar(c.elegir());

            while (!valores.conjuntoVacio()) {

                d1.agregar(clave, valores.elegir());
                valores.sacar(valores.elegir());
            }

            c.sacar(c.elegir());
        }

        return d1;
    }

    public DiccionarioMultipleTDA interseccionElementosPorClave(DiccionarioMultipleTDA d1, DiccionarioMultipleTDA d2){
        return d1;
    }

    public DiccionarioMultipleTDA interseccionClaves(DiccionarioMultipleTDA d1, DiccionarioMultipleTDA d2){

        OperacionConjunto m = new OperacionConjunto();
        ConjuntoTDA c1 = d1.claves();
        ConjuntoTDA c2 = d2.claves();
        ConjuntoTDA c = m.interseccion(c1, c2);

        DiccionarioMultipleTDA dicNuevo = new DicMultipleDinamico();

        while (!c.conjuntoVacio()) {

            int clave = c.elegir();
            ConjuntoTDA valores1 = d1.recuperar(c.elegir());
            ConjuntoTDA valores2 = d2.recuperar(c.elegir());

            while (!valores1.conjuntoVacio() || !valores2.conjuntoVacio()) {

                if (!valores1.conjuntoVacio()) {
                    dicNuevo.agregar(clave, valores1.elegir());
                    valores1.sacar(valores1.elegir());
                }

                if (!valores2.conjuntoVacio()) {
                    dicNuevo.agregar(clave, valores2.elegir());
                    valores2.sacar(valores2.elegir());
                }
            }

            c.sacar(c.elegir());
        }

        return dicNuevo;
    }

    public DiccionarioMultipleTDA interseccion(DiccionarioMultipleTDA d1, DiccionarioMultipleTDA d2){

        return d1;
    }

    public void imprimir(DiccionarioMultipleTDA diccionario){
        ConjuntoTDA c = diccionario.claves();

        while (!c.conjuntoVacio()) {

            int clave = c.elegir();
            ConjuntoTDA valores = diccionario.recuperar(c.elegir());

            System.out.print("clave: " + clave + " | valor: ");

            while (!valores.conjuntoVacio()) {

                System.out.print(valores.elegir());
                valores.sacar(valores.elegir());
            }
            System.out.println(' ');

            c.sacar(c.elegir());
        }
    }
    
    public DiccionarioMultipleTDA unionValoresCC(DiccionarioMultipleTDA d1, DiccionarioMultipleTDA d2) {
        DiccionarioMultipleTDA diccionario = new DicMultipleDinamico();
        diccionario.inicializarDiccionario();

        // Claves comunes entre D1 y D2
        OperacionConjunto operacion = new OperacionConjunto();
        ConjuntoTDA clavesComunes = operacion.interseccion(d1.claves(), d2.claves());

        while (!clavesComunes.conjuntoVacio()) {
            int clave = clavesComunes.elegir();
            ConjuntoTDA valoresD1 = d1.recuperar(clave);
            ConjuntoTDA valoresD2 = d2.recuperar(clave);

            // Agregar todos los valores de ambas claves
            while (!valoresD1.conjuntoVacio()) {
                diccionario.agregar(clave, valoresD1.elegir());
                valoresD1.sacar(valoresD1.elegir());
            }
            while (!valoresD2.conjuntoVacio()) {
                diccionario.agregar(clave, valoresD2.elegir());
                valoresD2.sacar(valoresD2.elegir());
            }

            clavesComunes.sacar(clave);
        }

        return diccionario;
    }
    
    public DiccionarioMultipleTDA interseccionCYV(DiccionarioMultipleTDA d1, DiccionarioMultipleTDA d2) {
        DiccionarioMultipleTDA diccionario = new DicMultipleDinamico();
        diccionario.inicializarDiccionario();

        // Claves comunes entre D1 y D2
        OperacionConjunto operacion = new OperacionConjunto();
        ConjuntoTDA clavesComunes = operacion.interseccion(d1.claves(), d2.claves());

        while (!clavesComunes.conjuntoVacio()) {
            int clave = clavesComunes.elegir();
            ConjuntoTDA valoresD1 = d1.recuperar(clave);
            ConjuntoTDA valoresD2 = d2.recuperar(clave);

            // Intersección de los valores para la clave
            ConjuntoTDA valoresComunes = operacion.interseccion(valoresD1, valoresD2);
            while (!valoresComunes.conjuntoVacio()) {
                diccionario.agregar(clave, valoresComunes.elegir());
                valoresComunes.sacar(valoresComunes.elegir());
            }

            clavesComunes.sacar(clave);
        }

        return diccionario;
    }

}


