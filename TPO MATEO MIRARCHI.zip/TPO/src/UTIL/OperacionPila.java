package UTIL;

import API.ColaTDA;
import API.ConjuntoTDA;
import API.PilaTDA;
import IMPL.ColaEstatica;
import IMPL.ConjuntoEstatico;
import IMPL.PilaEstatica;

import java.util.Scanner;

public class OperacionPila {

	public static void mostrarPila(PilaTDA pila) {
        if (pila.pilaVacia()) {
            System.out.println("La pila está vacía.");
            return;
        }

        PilaTDA pilaAux = new PilaEstatica();
        pilaAux.inicializarPila();

        System.out.print("Contenido de la pila: ");
        while (!pila.pilaVacia()) {
            int elemento = pila.tope();
            System.out.print(elemento + " ");
            pilaAux.apilar(elemento);
            pila.desapilar();
        }
        System.out.println(); 

        while (!pilaAux.pilaVacia()) {
            pila.apilar(pilaAux.tope());
            pilaAux.desapilar();
        }
    }

    public void llenar(PilaTDA pila, Scanner scanner) {
        System.out.println("Ingrese la cantidad de elementos para la pila: ");
        int n = scanner.nextInt();

        System.out.println("Ingrese los elementos de la pila: ");
        for (int i = 0; i < n; i++) {
            int elemento = scanner.nextInt();
            pila.apilar(elemento);
        }
    }

    public boolean contieneElemento(PilaTDA mod, int elementoDada) {
        PilaTDA aux = new PilaEstatica();
        aux.inicializarPila();

        boolean encontrado = false;

        while (!mod.pilaVacia()) {
            int elementoMod = mod.tope();
            mod.desapilar();

            if (elementoMod == elementoDada) {
                encontrado = true;
            }

            aux.apilar(elementoMod);
        }

        while (!aux.pilaVacia()) {
            mod.apilar(aux.tope());
            aux.desapilar();
        }

        return encontrado;
    }

    public void pasarPila(PilaTDA origen, PilaTDA destino) {
        while (!origen.pilaVacia()) {
            destino.apilar(origen.tope());
            origen.desapilar();
        }
    }

    public int contarElementos(PilaTDA pila) {
        int contador = 0;

        PilaTDA aux = new PilaEstatica();
        aux.inicializarPila();

        while (!pila.pilaVacia()) {
            aux.apilar(pila.tope());
            pila.desapilar();
            contador++;
        }

        while (!aux.pilaVacia()) {
            pila.apilar(aux.tope());
            aux.desapilar();
        }

        return contador;
    }

    public void copiarPila(PilaTDA origen, PilaTDA destino) {
        PilaTDA auxiliar = new PilaEstatica();
        auxiliar.inicializarPila();

        while (!origen.pilaVacia()) {
            auxiliar.apilar(origen.tope());
            origen.desapilar();
        }

        while (!auxiliar.pilaVacia()) {
            destino.apilar(auxiliar.tope());
            origen.apilar(auxiliar.tope());
            auxiliar.desapilar();
        }
    }
    
    public static PilaTDA invertirPila(PilaTDA pilaOriginal) {
        if (!pilaOriginal.pilaVacia()) {
            int aux = pilaOriginal.tope();
            pilaOriginal.desapilar(); 

            invertirPila(pilaOriginal);

            PilaTDA temporal = new PilaEstatica();
            temporal.inicializarPila();
            while (!pilaOriginal.pilaVacia()) {
                temporal.apilar(pilaOriginal.tope());
                pilaOriginal.desapilar();
            }

            pilaOriginal.apilar(aux);

            while (!temporal.pilaVacia()) {
                pilaOriginal.apilar(temporal.tope());
                temporal.desapilar();
            }
        }

        return pilaOriginal;
    }
    
    public int sumarPila (PilaTDA pilaOriginal){
    	PilaTDA pilaAux = new PilaEstatica();
    	pilaAux.inicializarPila();
    	
        int suma = 0;

        while (!pilaOriginal.pilaVacia()){
            suma += pilaOriginal.tope();
            pilaAux.apilar(pilaOriginal.tope());
            pilaOriginal.desapilar();
        }
        
        while(!pilaAux.pilaVacia()) {
        	pilaOriginal.apilar(pilaAux.tope());
        	pilaAux.desapilar();
        }

        return suma;
    }
    
    public boolean esCapicua(PilaTDA pilaOriginal) {
    	PilaTDA pilaAux = new PilaEstatica();
    	pilaAux.inicializarPila();
        
        invertirPila(pilaOriginal);
        copiarPila(pilaOriginal, pilaAux);
        invertirPila(pilaOriginal);

        while (pilaOriginal.tope() == pilaAux.tope() && !pilaOriginal.pilaVacia()){
            pilaOriginal.desapilar();
            pilaAux.desapilar();
        }
    	return pilaOriginal.tope() == pilaAux.tope();
    }
    
    public void repartirPilas(PilaTDA pila, PilaTDA mitad1, PilaTDA mitad2) {
    	
    	boolean repartirPila = true;
    	
    	while(!pila.pilaVacia()) {
    		if(repartirPila == true) {
    			mitad1.apilar(pila.tope());
    			pila.desapilar();
    			repartirPila = false;
    		}else{
    			mitad2.apilar(pila.tope());
    			pila.desapilar();
    			repartirPila = true;
    		}
    	}
    	
    }
    
    public PilaTDA eliminarRepetidos(PilaTDA pila) {
    	
    	PilaTDA pilaAux = new PilaEstatica();
    	pilaAux.inicializarPila();
    	
    	PilaTDA pilaResultado = new PilaEstatica();
    	pilaResultado.inicializarPila();
    	
    	invertirPila(pila);
    	copiarPila(pila, pilaAux);
    	invertirPila(pila);
    	
    	while(!pilaAux.pilaVacia()) {
    		if(!contieneElemento(pilaResultado, pilaAux.tope())) {
    			pilaResultado.apilar(pilaAux.tope());
    			pilaAux.desapilar();
    		}else {
    			pilaAux.desapilar();
    		}
    	}
    	
    	return pilaResultado;
    }
    
    public void rellenarConjunto(PilaTDA pila, ConjuntoTDA conjunto) {
    	
    	PilaTDA pilaAux = new PilaEstatica();
    	pilaAux.inicializarPila();
    	
    	while(!pila.pilaVacia()) {
    		if(contieneElemento(pilaAux, pila.tope())) {
    			conjunto.agregar(pila.tope());
    			pila.desapilar();
    		}else {
    			pilaAux.apilar(pila.tope());
    			pila.desapilar();
    		}
    	}
    }
    	
}

