package UTIL;

import java.util.Scanner;
import API.ColaPrioridadTDA;
import API.ConjuntoTDA;
import API.DiccionarioMultipleTDA;
import IMPL.ColaPrioridadEstatica;

public class OperacionColaPrioridad {
	
	public void mostrar(ColaPrioridadTDA cola) {
    	
    	while(cola.colaVacia()) {
    		System.out.println("La cola esta vacia.");
    		return;
    	}
    	
    	ColaPrioridadTDA colaAux = new ColaPrioridadEstatica();
    	colaAux.inicializarCola();
    	
            System.out.print('[');
            while(!cola.colaVacia()){

                System.out.print('[');
                System.out.print(cola.primero());
                System.out.print(", ");
                System.out.print(cola.prioridad());
                System.out.print(']');

                System.out.print(", ");

                
                colaAux.acolarPrioridad(cola.primero(), cola.prioridad());
                cola.desacolar();

        }
            System.out.print(']');
        
        while(!colaAux.colaVacia()) {
        	cola.acolarPrioridad(colaAux.primero(), colaAux.prioridad());
        	colaAux.desacolar();
        }
        
        
    }
	
	public void llenarConPrioridad(ColaPrioridadTDA cola, Scanner scanner) {
	    System.out.println("Ingrese la cantidad de elementos para la cola con prioridad: ");
	    int n = scanner.nextInt();

	    System.out.println("Ingrese los elementos y sus prioridades (elemento prioridad): ");
	    for (int i = 0; i < n; i++) {
	        System.out.print("Elemento: ");
	        int elemento = scanner.nextInt();
	        System.out.print("Prioridad: ");
	        int prioridad = scanner.nextInt();
	        cola.acolarPrioridad(elemento, prioridad);
	    }
	}

	
	public ColaPrioridadTDA combinarColas(ColaPrioridadTDA colaPrio1, ColaPrioridadTDA colaPrio2) {
		
		ColaPrioridadTDA colaFinal = new ColaPrioridadEstatica();
		colaFinal.inicializarCola();

		while(!colaPrio2.colaVacia() || !colaPrio1.colaVacia()) {
			if(colaPrio1.colaVacia()) {
				colaFinal.acolarPrioridad(colaPrio2.primero(), colaPrio2.prioridad());
				colaPrio2.desacolar();
			}else if(colaPrio2.colaVacia()) {
				colaFinal.acolarPrioridad(colaPrio1.primero(), colaPrio1.prioridad());
				colaPrio1.desacolar();
			}else if(colaPrio1.prioridad() > colaPrio2.prioridad()) {
				colaFinal.acolarPrioridad(colaPrio1.primero(), colaPrio1.prioridad());
				colaPrio1.desacolar();
			}else if(colaPrio2.prioridad() > colaPrio1.prioridad()){
				colaFinal.acolarPrioridad(colaPrio2.primero(), colaPrio2.prioridad());
				colaPrio2.desacolar();
			}else {
				colaFinal.acolarPrioridad(colaPrio1.primero(), colaPrio1.prioridad());
				colaPrio1.desacolar();
			}
		}
		
		return colaFinal;
	}
	
	public boolean sonIdenticas(ColaPrioridadTDA colaPrio1, ColaPrioridadTDA colaPrio2) {

        while (
                !colaPrio1.colaVacia()
                        && !colaPrio2.colaVacia()
                        && colaPrio1.primero() == colaPrio2.primero()
                        && colaPrio1.prioridad() == colaPrio2.prioridad()
        ){
        	colaPrio1.desacolar();
            colaPrio2.desacolar();
        }

        return colaPrio1.colaVacia() && colaPrio2.colaVacia();
    }
	
	public void GenerarDiccionarioMultiple(ColaPrioridadTDA cola, ConjuntoTDA valores, DiccionarioMultipleTDA diccionario) {

        while (!cola.colaVacia()) {
            int valor = cola.primero();  
            int prioridad = cola.prioridad();
            cola.desacolar();

            if (!valores.pertenece(valor)) {
                valores.agregar(valor);
                diccionario.agregar(valor, prioridad); 
            } else {
                diccionario.agregar(valor, prioridad); 
            }
        }
    }


}
