package UTIL;

import API.ColaTDA;
import API.ConjuntoTDA;
import API.PilaTDA;
import IMPL.ConjuntoEstatico;


public class OperacionConjunto {

    public void mostrarConjunto(ConjuntoTDA conjunto) {
        ConjuntoTDA aux = new ConjuntoEstatico(); 
        aux.inicializarConjunto();

        System.out.print("Elementos del conjunto: ");
        while (!conjunto.conjuntoVacio()) {
            int elemento = conjunto.elegir(); 
            System.out.print(elemento + " ");  
            conjunto.sacar(elemento);          
            aux.agregar(elemento);             
        }
        System.out.println(); 

        
        while (!aux.conjuntoVacio()) {
            int elemento = aux.elegir();
            aux.sacar(elemento);
            conjunto.agregar(elemento);
        }
    }
    
    public ConjuntoTDA interseccion(ConjuntoTDA conjunto1, ConjuntoTDA conjunto2){

        int valor1;

        if (!conjunto1.conjuntoVacio()){

            valor1 = conjunto1.elegir();
            conjunto1.sacar(valor1);

            interseccion(conjunto1, conjunto2);

            if (conjunto2.pertenece(valor1)){
                conjunto1.agregar(valor1);
            }
        }

        return conjunto1;
    }

    public ConjuntoTDA union(ConjuntoTDA conjunto1, ConjuntoTDA conjunto2){

        while (!conjunto2.conjuntoVacio()){
            conjunto1.agregar(conjunto2.elegir());
            conjunto2.sacar(conjunto2.elegir());
        }

        return conjunto1;
    }

    public ConjuntoTDA diferencia(ConjuntoTDA conjunto1, ConjuntoTDA conjunto2){

        while (!conjunto2.conjuntoVacio()){
            conjunto1.sacar(conjunto2.elegir());
            conjunto2.sacar(conjunto2.elegir());
        }

        return conjunto1;
    }

    public void copiarConjunto(ConjuntoTDA origen, ConjuntoTDA destino) {
        ConjuntoTDA auxiliar = new ConjuntoEstatico();
        auxiliar.inicializarConjunto();

        while (!origen.conjuntoVacio()) {
            int elemento = origen.elegir();
            origen.sacar(elemento);
            destino.agregar(elemento);
            auxiliar.agregar(elemento);
        }

        while (!auxiliar.conjuntoVacio()) {
            int elemento = auxiliar.elegir();
            auxiliar.sacar(elemento);
            origen.agregar(elemento);
        }
    }

    public void imprimir(ConjuntoTDA conjunto) {
        if (conjunto.conjuntoVacio()) {
            System.out.println("El conjunto está vacío");
            return;
        }

        ConjuntoTDA copia = new ConjuntoEstatico();
        copia.inicializarConjunto();

        copiarConjunto(conjunto, copia);

        System.out.print('[');
        while (!copia.conjuntoVacio()) {
            int elemento = copia.elegir();
            copia.sacar(elemento);

            System.out.print(elemento);
            if (!copia.conjuntoVacio()) {
                System.out.print(", ");
            }
        }
        System.out.println(']');
    }

    public ConjuntoTDA diferenciaSimetricaSinOperaciones(ConjuntoTDA conjunto1, ConjuntoTDA conjunto2) {
        ConjuntoTDA resultado = new ConjuntoEstatico();
        resultado.inicializarConjunto();

        ConjuntoTDA copia1 = new ConjuntoEstatico();
        ConjuntoTDA copia2 = new ConjuntoEstatico();
        copia1.inicializarConjunto();
        copia2.inicializarConjunto();

        copiarConjunto(conjunto1, copia1);
        copiarConjunto(conjunto2, copia2);

        while (!copia1.conjuntoVacio()) {
            int elemento = copia1.elegir();
            copia1.sacar(elemento);

            if (!conjunto2.pertenece(elemento)) {
                resultado.agregar(elemento);
            }
        }

        while (!copia2.conjuntoVacio()) {
            int elemento = copia2.elegir();
            copia2.sacar(elemento);

            if (!conjunto1.pertenece(elemento)) {
                resultado.agregar(elemento);
            }
        }

        return resultado;
    }
    
    public ConjuntoTDA diferenciaSimetricaConOperaciones(ConjuntoTDA conjunto1, ConjuntoTDA conjunto2) {
        ConjuntoTDA copia1 = new ConjuntoEstatico();
        ConjuntoTDA copia2 = new ConjuntoEstatico();
        copia1.inicializarConjunto();
        copia2.inicializarConjunto();

        copiarConjunto(conjunto1, copia1);
        copiarConjunto(conjunto2, copia2);

        ConjuntoTDA union = union(copia1, copia2);

        ConjuntoTDA copia3 = new ConjuntoEstatico();
        ConjuntoTDA copia4 = new ConjuntoEstatico();
        copia3.inicializarConjunto();
        copia4.inicializarConjunto();

        copiarConjunto(conjunto1, copia3);
        copiarConjunto(conjunto2, copia4);

        ConjuntoTDA interseccion = interseccion(copia3, copia4);

        return diferencia(union, interseccion);
    }

    public ConjuntoTDA diferenciaSimetrica(ConjuntoTDA conjunto1, ConjuntoTDA conjunto2) {
        ConjuntoTDA copia1 = new ConjuntoEstatico();
        ConjuntoTDA copia2 = new ConjuntoEstatico();
        copia1.inicializarConjunto();
        copia2.inicializarConjunto();

        copiarConjunto(conjunto1, copia1);
        copiarConjunto(conjunto2, copia2);

        ConjuntoTDA union = union(copia1, copia2);

        ConjuntoTDA copia3 = new ConjuntoEstatico();
        ConjuntoTDA copia4 = new ConjuntoEstatico();
        copia3.inicializarConjunto();
        copia4.inicializarConjunto();

        copiarConjunto(conjunto1, copia3);
        copiarConjunto(conjunto2, copia4);

        ConjuntoTDA interseccion = interseccion(copia3, copia4);

        return diferencia(union, interseccion);
    }


    public boolean sonIguales(ConjuntoTDA conjunto1, ConjuntoTDA conjunto2) {
        ConjuntoTDA copia1 = new ConjuntoEstatico();
        ConjuntoTDA copia2 = new ConjuntoEstatico();
        copia1.inicializarConjunto();
        copia2.inicializarConjunto();

        copiarConjunto(conjunto1, copia1);
        copiarConjunto(conjunto2, copia2);

        while (!copia1.conjuntoVacio()) {
            int elemento = copia1.elegir();
            copia1.sacar(elemento);

            if (!copia2.pertenece(elemento)) {
                return false;
            }
        }

        return copia2.conjuntoVacio();
    }


    public int cardinalidad(ConjuntoTDA conjunto) {
        int contador = 0;

        ConjuntoTDA copia = new ConjuntoEstatico();
        copia.inicializarConjunto();

        copiarConjunto(conjunto, copia);

        while (!copia.conjuntoVacio()) {
            copia.sacar(copia.elegir());
            contador++;
        }

        return contador;
    }


    public ConjuntoTDA elementosComunes(PilaTDA pila, ColaTDA cola) {
        ConjuntoTDA resultado = new ConjuntoEstatico();
        resultado.inicializarConjunto();

        ConjuntoTDA elementosCola = new ConjuntoEstatico();
        elementosCola.inicializarConjunto();

        while (!cola.colaVacia()) {
            int elemento = cola.primero();
            cola.desacolar();
            elementosCola.agregar(elemento);
        }

        while (!pila.pilaVacia()) {
            int elemento = pila.tope();
            pila.desapilar();

            if (elementosCola.pertenece(elemento)) {
                resultado.agregar(elemento);
            }
        }

        return resultado;
    }

    public boolean mismosElementos(PilaTDA pila, ColaTDA cola) {
        ConjuntoTDA elementosPila = new ConjuntoEstatico();
        ConjuntoTDA elementosCola = new ConjuntoEstatico();

        elementosPila.inicializarConjunto();
        elementosCola.inicializarConjunto();

        while (!pila.pilaVacia()) {
            elementosPila.agregar(pila.tope());
            pila.desapilar();
        }

        while (!cola.colaVacia()) {
            elementosCola.agregar(cola.primero());
            cola.desacolar();
        }

        return sonIguales(elementosPila, elementosCola);
    }

}
