package UTIL;

import API.PilaTDA;
import API.ColaTDA;
import API.ConjuntoTDA;
import IMPL.ColaEstatica;
import IMPL.PilaEstatica;

import java.util.Scanner;

public class OperacionCola {
    
    public void mostrar(ColaTDA cola) {
    	while(cola.colaVacia()) {
    		System.out.println("La cola esta vacia.");
    		return;
    	}
    	
    	ColaTDA colaAuxiliarVuelta = new ColaEstatica();
    	colaAuxiliarVuelta.inicializarCola();
    	
        while (!cola.colaVacia()) {
            System.out.println(cola.primero());
            colaAuxiliarVuelta.acolar(cola.primero());
            cola.desacolar();
        }
        
        while(!colaAuxiliarVuelta.colaVacia()) {
        	cola.acolar(colaAuxiliarVuelta.primero());
        	colaAuxiliarVuelta.desacolar();
        }
    
    }

    public void llenar(ColaTDA cola, Scanner scanner) {
        System.out.println("Ingrese la cantidad de elementos para la cola: ");
        int n = scanner.nextInt();

        System.out.println("Ingrese los elementos de la cola: ");
        for (int i = 0; i < n; i++) {
            int elemento = scanner.nextInt();
            cola.acolar(elemento);
        }
    }
    
    public static ColaTDA copiarCola(ColaTDA colaOriginal, ColaTDA colaAux) {
        ColaTDA colaCopia = new ColaEstatica();
        colaCopia.inicializarCola();

        while(!colaOriginal.colaVacia()) {
            colaCopia.acolar(colaOriginal.primero());
            colaAux.acolar(colaOriginal.primero());
            colaOriginal.desacolar();
        }

        while (!colaCopia.colaVacia()) {
            colaOriginal.acolar(colaCopia.primero());
            colaCopia.desacolar();
        }

        return colaAux;
    }

    public void pasarCola(ColaTDA Origen, ColaTDA Destino) {
        while (!Origen.colaVacia()) {
            Destino.acolar(Origen.primero());
            Origen.desacolar();
        }
    }

    public static ColaTDA invertirCola(ColaTDA colaOriginal){

        if (!colaOriginal.colaVacia()){
            int aux = colaOriginal.primero();
            colaOriginal.desacolar();

            invertirCola(colaOriginal);

            colaOriginal.acolar(aux);
        }

        return colaOriginal;
    }
    
    public void invertirColaConPila(ColaTDA cola) {
    	
    	PilaTDA pilaAux = new PilaEstatica();
    	pilaAux.inicializarPila();
    	
		while(!cola.colaVacia()) {
			pilaAux.apilar(cola.primero());
			cola.desacolar();
		}
		
		while(!pilaAux.pilaVacia()) {
			cola.acolar(pilaAux.tope());
			pilaAux.desapilar();
		}
		
    }

    public static Boolean coincideFinal(ColaTDA cola1, ColaTDA cola2){

        boolean respuesta;

        invertirCola(cola1);
        invertirCola(cola2);

        respuesta = cola1.primero() == cola2.primero();

        invertirCola(cola1);
        invertirCola(cola2);

        return respuesta;
    }

    public static Boolean esCapicua(ColaTDA colaorginal){
        ColaTDA colaAux = new ColaEstatica();
        colaAux.inicializarCola();
        
        invertirCola(colaorginal);
        copiarCola(colaorginal, colaAux);
        invertirCola(colaorginal);

        while (colaorginal.primero() == colaAux.primero() && !colaorginal.colaVacia()){
            colaorginal.desacolar();
            colaAux.desacolar();
        }

        return colaorginal.primero() == colaAux.primero();
    }
    
    public static Boolean esInversa(ColaTDA cola1, ColaTDA cola2) {
    	
    	ColaTDA colaAux1 = new ColaEstatica();
    	colaAux1.inicializarCola();
    	copiarCola(cola1, colaAux1);
    	
    	ColaTDA colaAux2 = new ColaEstatica();
    	colaAux2.inicializarCola();
    	copiarCola(cola2, colaAux2);
    	
    	invertirCola(colaAux2);
    	
    	while(!colaAux1.colaVacia() || !colaAux2.colaVacia()){
        	if((!colaAux1.colaVacia() && colaAux2.colaVacia()) || (!colaAux2.colaVacia() && colaAux1.colaVacia())) {
        		return false;
        	}
    		if(colaAux1.primero() == colaAux2.primero()) {
                colaAux1.desacolar();
                colaAux2.desacolar();
    		}else{
    			return false;
    		}
        }
    	
    	return true;
    }
    
    public boolean contieneElemento(ColaTDA mod, int elementoDada) {
        ColaTDA aux = new ColaEstatica();
        aux.inicializarCola();

        boolean encontrado = false;

        while (!mod.colaVacia()) {
            int elementoMod = mod.primero();
            mod.desacolar();

            if (elementoMod == elementoDada) {
                encontrado = true;
            }

            aux.acolar(elementoMod);
        }

        while (!aux.colaVacia()) {
            mod.acolar(aux.primero());
            aux.desacolar();
        }

        return encontrado;
    }
    
    public void copiarSinRepetidos(ColaTDA origen) {
        ColaTDA auxiliar = new ColaEstatica();
        auxiliar.inicializarCola();

        ColaTDA temporal = new ColaEstatica();
        temporal.inicializarCola();

        while (!origen.colaVacia()) {
            int elemento = origen.primero();
            origen.desacolar();

            if (!contieneElemento(temporal, elemento)) {
                auxiliar.acolar(elemento);
                temporal.acolar(elemento); 
            }
        }
    }
    
    public void copiarSoloRepetidos(ColaTDA origen, ConjuntoTDA conjunto) {
        ColaTDA auxiliar = new ColaEstatica();
        auxiliar.inicializarCola();

        ColaTDA temporal = new ColaEstatica();
        temporal.inicializarCola();

        while (!origen.colaVacia()) {
            int elemento = origen.primero();
            origen.desacolar();

            if (contieneElemento(temporal, elemento)) {
                if (!contieneElemento(auxiliar, elemento)) {
                    auxiliar.acolar(elemento); 
                }
            } else {
                temporal.acolar(elemento); 
            }
        }

        while (!auxiliar.colaVacia()) {
            conjunto.agregar(auxiliar.primero());
            auxiliar.desacolar();
        }
    }

    public int contarElementos(ColaTDA cola) {
        int contador = 0;

        PilaTDA aux = new PilaEstatica();
        aux.inicializarPila();

        while (!cola.colaVacia()) {
            aux.apilar(cola.primero());
            cola.desacolar();
            contador++;
        }

        while (!aux.pilaVacia()) {
            cola.acolar(aux.tope());
            aux.desapilar();
        }

        return contador;
    }

    public void dividirMitad (ColaTDA original, ColaTDA mitad1, ColaTDA mitad2) {
        ColaTDA auxiliar = new ColaEstatica();
        auxiliar.inicializarCola();

        int cant = contarElementos(original);
        int mitad = cant / 2;

        while (!original.colaVacia()) {
            auxiliar.acolar(original.primero());
            original.desacolar();
        }

        for (int i = 0; i < mitad; i++) {
            mitad1.acolar(auxiliar.primero());
            auxiliar.desacolar();
        }

        while (!auxiliar.colaVacia()) {
            mitad2.acolar(auxiliar.primero());
            auxiliar.desacolar();
        }
    }
}
