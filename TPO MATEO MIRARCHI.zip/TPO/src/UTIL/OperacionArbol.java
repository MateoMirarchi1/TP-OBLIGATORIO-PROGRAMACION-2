package UTIL;

import API.ABBTDA;
import API.ConjuntoTDA;

public class OperacionArbol {
    
    public static boolean pertenece(int n, ABBTDA arbol) {
		if (arbol.arbolVacio()) {
			return false;
		} else if (arbol.raiz()==n) {
			return true;
		} else if (arbol.raiz() > n) {
			return pertenece(n,arbol.hijoIzq());
		} else {
			return pertenece(n,arbol.hijoDer());
		}
	}
    
    public static boolean esHoja(int n, ABBTDA arbol) {
		if (arbol.arbolVacio()) {
			return false;
		} else if (arbol.raiz()==n && arbol.hijoDer().arbolVacio() && arbol.hijoIzq().arbolVacio()) {
			return true;
		} else if (arbol.raiz()>n) {
			return esHoja(n,arbol.hijoIzq());
		} else {
			return esHoja(n,arbol.hijoDer());
		}
	}
    
    public static int profundidad (int n,ABBTDA arbol) {
		if (arbol.arbolVacio()) {
			return 0;
		} else if (arbol.raiz()==n) {
			return 0;
		} else if (arbol.raiz()>n) {
			return (1+profundidad(n,arbol.hijoIzq()));
		} else {
			return (1+profundidad(n,arbol.hijoDer()));
		}
	}
    
    public static int menor(ABBTDA arbol) {
		if(arbol.arbolVacio()) {
			return 0;
		} else if (arbol.hijoIzq().arbolVacio()) {
			return (arbol.raiz());
		} else {
			return (menor(arbol.hijoIzq()));
		}
	}
	
    public static int cantElementos(ABBTDA arbol) {
		if (arbol.arbolVacio()) {
			return 0;
		} else {
			return(1+cantElementos(arbol.hijoDer())+cantElementos(arbol.hijoIzq()));
		}
	}
    
    public static int suma(ABBTDA arbol) {
		if (arbol.arbolVacio()) {
			return 0;
		} else {
			return(arbol.raiz()+suma(arbol.hijoDer())+suma(arbol.hijoIzq()));
		}
	}
    
    public static int cantHojas(ABBTDA arbol) {
		if (arbol.arbolVacio()) {
			return 0;
		} else if (arbol.hijoIzq().arbolVacio() && arbol.hijoDer().arbolVacio()) {
			return (1);
		} else {
			return (cantHojas(arbol.hijoDer())+cantHojas(arbol.hijoIzq()));
		}
	}
    
    public static int altura(ABBTDA arbol) {
		if (arbol.arbolVacio()) {
			return -1;
		} else if (altura(arbol.hijoDer())>altura(arbol.hijoIzq())) {
			return (altura(arbol.hijoDer())+1);
		} else {
			return (altura(arbol.hijoIzq())+1);
		}
	}
    
    public static boolean mismaForma(ABBTDA arbol,ABBTDA arbol2) {
		if (arbol.arbolVacio() && arbol2.arbolVacio()) {
			return true;
		} else if ((arbol.arbolVacio() && !arbol2.arbolVacio()) || (!arbol.arbolVacio() && arbol2.arbolVacio()) ){
			return false;
		}
		else if ((arbol.hijoDer().arbolVacio()==arbol2.hijoDer().arbolVacio()) && (arbol.hijoIzq().arbolVacio()==arbol2.hijoIzq().arbolVacio())) {
			return (mismaForma(arbol.hijoDer(),arbol2.hijoDer()) && mismaForma(arbol.hijoIzq(),arbol2.hijoIzq()));
		} else {
			return false;
		}
	}
    
    public static boolean sonIguales(ABBTDA arbol,ABBTDA arbol2) {
		if (arbol.arbolVacio() && arbol2.arbolVacio()) {
			return true;
		} else if ((arbol.arbolVacio() && !arbol2.arbolVacio()) || (!arbol.arbolVacio() && arbol2.arbolVacio()) || (arbol.raiz()!=arbol2.raiz()) ){
			return false;
		}
		else if ((arbol.hijoDer().arbolVacio()==arbol2.hijoDer().arbolVacio()) && (arbol.hijoIzq().arbolVacio()==arbol2.hijoIzq().arbolVacio()) && (arbol.raiz()==arbol2.raiz()) ) {
			return (sonIguales(arbol.hijoDer(),arbol2.hijoDer()) == sonIguales(arbol.hijoIzq(),arbol2.hijoIzq()));
		} else {
			return false;
		}
	}
    
	public static int contPorNivel(ABBTDA arbol, int N) {
		if (arbol.arbolVacio()) {
			return 0;
		} else if(N==1) {
			if (!arbol.hijoDer().arbolVacio() && !arbol.hijoIzq().arbolVacio()) {
				return 2;
			} else if (!arbol.hijoDer().arbolVacio() || !arbol.hijoIzq().arbolVacio()) {
				return 1;
			} else {
				return 0;
			}
		} else if(N==0) {
			return 0;
		} else {
			return (contPorNivel(arbol.hijoDer(),N-1)+contPorNivel(arbol.hijoIzq(),N-1));
		}
		
	}
	
	public static void mostrarInOrder(ABBTDA arbol) {
	    if (!arbol.arbolVacio()) {
	        mostrarInOrder(arbol.hijoIzq()); 
	        System.out.print(arbol.raiz() + " ");  
	        mostrarInOrder(arbol.hijoDer());
	    }
	}
	
	public static void mostrarPreOrder(ABBTDA arbol) {
		if (!arbol.arbolVacio()) {
			System.out.print(arbol.raiz() + " ");
			mostrarPreOrder(arbol.hijoIzq());
			mostrarPreOrder(arbol.hijoDer());
		}
	}
	
	public static void mostrarPostOrder(ABBTDA arbol) {
		if (!arbol.arbolVacio()) {
			mostrarPostOrder(arbol.hijoIzq());
			mostrarPostOrder(arbol.hijoDer());
			System.out.print(arbol.raiz() + " ");
		}
	}
	
	public static ConjuntoTDA conjuntoMayores(ABBTDA arbol,int k, ConjuntoTDA c) {
		if (arbol.arbolVacio()) {
			return c;
		} else if (arbol.raiz()>k) {
			c.agregar(arbol.raiz());
			conjuntoMayores(arbol.hijoDer(),k,c);
			conjuntoMayores(arbol.hijoIzq(),k,c);
			return c;
		} else {
			conjuntoMayores(arbol.hijoDer(),k,c);
			conjuntoMayores(arbol.hijoIzq(),k,c);
			return c;
		}
	}
	
	public static int anterior(ABBTDA arbol,int v) {
		if (arbol.arbolVacio()) {
			return 0;
		} else if (!arbol.hijoDer().arbolVacio() && arbol.hijoDer().raiz() == v) {
			return (arbol.raiz());
		} else if (!arbol.hijoIzq().arbolVacio() && arbol.hijoIzq().raiz() == v) {
			return (arbol.raiz());
		} else {
			return (anterior(arbol.hijoDer(),v) + anterior(arbol.hijoIzq(),v));
		}
	}
}

