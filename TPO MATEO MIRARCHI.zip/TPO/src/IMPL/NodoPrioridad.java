package IMPL;

public class NodoPrioridad {
    int info;
    int prioridad;
    NodoPrioridad sig;
}
