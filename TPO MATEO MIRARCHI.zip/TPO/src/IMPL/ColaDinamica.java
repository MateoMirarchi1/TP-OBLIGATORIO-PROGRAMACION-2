package IMPL;

import API.ColaTDA;

public class ColaDinamica implements ColaTDA {
    Nodo primero;
    Nodo ultimo;

    public void inicializarCola() {
        primero = null;
        ultimo = null;
    }
    public void acolar(int x) {
        Nodo aux = new Nodo();
        aux.info = x;
        aux.sig = null;
        if (primero==null) {
            primero = aux;
            ultimo = aux;
        } else {
            ultimo.sig = aux;
            ultimo = aux;
        }
    }
    public void desacolar() {
        primero = primero.sig;
        if (primero==null) {
            ultimo = null;
        }

    }
    public int primero() {
        return (primero.info);
    }
    public boolean colaVacia() {
        return (primero==null);
    }

}
