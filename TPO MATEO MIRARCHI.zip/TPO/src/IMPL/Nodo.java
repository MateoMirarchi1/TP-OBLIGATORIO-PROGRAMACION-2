package IMPL;

public class Nodo {
    int info;
    Nodo sig;
}
