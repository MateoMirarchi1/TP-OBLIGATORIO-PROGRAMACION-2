package TP1;

import java.util.Scanner;

import API.ColaTDA;
import API.PilaTDA;
import IMPL.ColaEstatica;
import IMPL.PilaEstatica;
import UTIL.OperacionCola;

public class EjercicioCUATRO {

	public static void main(String[] args) {
		
		//PUNTO A
		ColaTDA cola1 = new ColaEstatica();
		cola1.inicializarCola();
		
		OperacionCola operacion = new OperacionCola();
		Scanner scanner = new Scanner(System.in);
		
		operacion.llenar(cola1, scanner);
		
		ColaTDA colaCopiada = new ColaEstatica();
		colaCopiada.inicializarCola();
		
		operacion.pasarCola(cola1, colaCopiada);
		
		System.out.println("EJ A");
		System.out.println("La cola copiada es: ");
		operacion.mostrar(colaCopiada);
		
		//PUNTO B
		ColaTDA cola2 = new ColaEstatica();
		cola2.inicializarCola();
		
		operacion.llenar(cola2, scanner);
		operacion.invertirColaConPila(cola2);
		
		System.out.println("EJ B");
		System.out.println("La cola invertida es: ");
		operacion.mostrar(cola2);
		
		//PUNTO C
		
		ColaTDA cola3 = new ColaEstatica();
		cola3.inicializarCola();
		
		operacion.llenar(cola3, scanner);
		operacion.invertirCola(cola3);
		
		System.out.println("EJ C");
		operacion.mostrar(cola3);
		
		//PUNTO D
		
		ColaTDA cola4 = new ColaEstatica();
		cola4.inicializarCola();
		
		ColaTDA cola4Ultima = new ColaEstatica();
		cola4Ultima.inicializarCola();
		
		operacion.llenar(cola4, scanner);
		operacion.llenar(cola4Ultima, scanner);
		
		boolean resultado = operacion.coincideFinal(cola4, cola4Ultima);
		
		System.out.println("EJ D");
		if (resultado == true) {
			System.out.println("El ultimo elemento de las colas, son iguales");
		}else {
			System.out.println("El ultimo elemento de las colas, NO son iguales");
		}
		
		//PUNTO E
		
		ColaTDA colaCapicua = new ColaEstatica();
		colaCapicua.inicializarCola();
		
		operacion.llenar(colaCapicua, scanner);
		
		boolean resultadoCapicua = operacion.esCapicua(colaCapicua);
		
		System.out.println("EJ E");
		if (resultadoCapicua == true) {
			System.out.println("La cola es capicua.");
		}else {
			System.out.println("La cola NO es capicua.");
		}
		
		
		// PUNTO F
		
		ColaTDA cola5 = new ColaEstatica();
		cola5.inicializarCola();
		
		operacion.llenar(cola5, scanner);
		
		ColaTDA cola6 = new ColaEstatica();
		cola6.inicializarCola();
		
		operacion.llenar(cola6, scanner);
		
		boolean resultadoInversa = operacion.esInversa(cola5, cola6);
		
		System.out.println("EJ F");
		if (resultadoInversa == true) {
			System.out.println("La colas son inversas.");
		}else {
			System.out.println("La colas NO son inversas.");
		}
		
		
	}
	


}
