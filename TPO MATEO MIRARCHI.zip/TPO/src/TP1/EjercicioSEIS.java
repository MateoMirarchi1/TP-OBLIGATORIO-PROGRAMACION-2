package TP1;

import java.util.Scanner;

import API.ColaPrioridadTDA;
import IMPL.ColaPrioridadEstatica;
import UTIL.OperacionColaPrioridad;

public class EjercicioSEIS {

	public static void main(String[] args) {
		
		//PUNTO A
		
		ColaPrioridadTDA colaPrioridad1 = new ColaPrioridadEstatica();
		colaPrioridad1.inicializarCola();
		ColaPrioridadTDA colaPrioridad2 = new ColaPrioridadEstatica();
		colaPrioridad2.inicializarCola();
		
		 OperacionColaPrioridad operaciones = new OperacionColaPrioridad();
		 Scanner scanner = new Scanner(System.in);

		operaciones.llenarConPrioridad(colaPrioridad1, scanner);
		operaciones.llenarConPrioridad(colaPrioridad2, scanner);
		
		System.out.println("COLA 1: ");
		operaciones.mostrar(colaPrioridad1);
		
		System.out.println("");
		System.out.println("COLA 2: ");
		operaciones.mostrar(colaPrioridad2);
		
		ColaPrioridadTDA colaFinal = operaciones.combinarColas(colaPrioridad1, colaPrioridad2);
		
		System.out.println("");
		System.out.println("EJ A");
		System.out.println("La cola con prioridad es la siguente: ");
		operaciones.mostrar(colaFinal);
		
		
		//PUNTO B
		
		System.out.println("");
		ColaPrioridadTDA colaPrioridad3 = new ColaPrioridadEstatica();
		colaPrioridad3.inicializarCola();
		ColaPrioridadTDA colaPrioridad4 = new ColaPrioridadEstatica();
		colaPrioridad4.inicializarCola();
		
		operaciones.llenarConPrioridad(colaPrioridad3, scanner);
		operaciones.llenarConPrioridad(colaPrioridad4, scanner);
		
		boolean resultadoIdenticas = operaciones.sonIdenticas(colaPrioridad3, colaPrioridad4);
		
		System.out.println("EJ B");
		if(resultadoIdenticas == true) {
			System.out.println("Son identicas.");
		}else {
			System.out.println("NO son identicas.");
		}
		
	}

}
