package TP1;

import IMPL.PilaEstatica;
import API.PilaTDA;
import UTIL.OperacionPila;
import java.util.Scanner;


public class EjercicioDOS {

	public static void main(String[] args) {
		
		//PUNTO A
        PilaTDA pila1 = new PilaEstatica();
        pila1.inicializarPila();

        OperacionPila operaciones = new OperacionPila();

        Scanner scanner = new Scanner(System.in);
        operaciones.llenar(pila1, scanner);
        operaciones.mostrarPila(pila1);

        PilaTDA pilaInvertida = new PilaEstatica();
        pilaInvertida.inicializarPila();

        operaciones.pasarPila(pila1, pilaInvertida);

        System.out.println("EJ A");
        operaciones.mostrarPila(pilaInvertida);


        //PUNTO B

        PilaTDA pila2 = new PilaEstatica();
        pila2.inicializarPila();

        operaciones.llenar(pila2, scanner);

        PilaTDA pilaCopiada = new PilaEstatica();
        pilaCopiada.inicializarPila();

        operaciones.copiarPila(pila2, pilaCopiada);

        System.out.println("EJ B");
        operaciones.mostrarPila(pilaCopiada);

        //PUNTO C
        PilaTDA pila3 = new PilaEstatica();
        pila3.inicializarPila();

        operaciones.llenar(pila3, scanner);
        operaciones.invertirPila(pila3);

        System.out.println("EJ C");
        operaciones.mostrarPila(pila3);


        //PUNTO D

        PilaTDA pilaConteo = new PilaEstatica();
        pilaConteo.inicializarPila();

        operaciones.llenar(pilaConteo, scanner);
        int cont = operaciones.contarElementos(pilaConteo);

        System.out.println("EJ D");
        System.out.println("La cantidad de elementos de la pila es: " + cont );


        //PUNTO E

        PilaTDA pilaSuma = new PilaEstatica();
        pilaSuma.inicializarPila();
        
        operaciones.llenar(pilaSuma, scanner);
        int suma = operaciones.sumarPila(pilaSuma);

        System.out.println("EJ E");
        System.out.println("La suma de los numeros de la Pila es: " + suma);
        operaciones.mostrarPila(pilaSuma);

        //PUNTO F
        PilaTDA pila4 = new PilaEstatica();
        pila4.inicializarPila();

        operaciones.llenar(pila4, scanner);
        
        int contador = operaciones.contarElementos(pila4);
        int sumaPila4 = operaciones.sumarPila(pila4);
        
        int promedio = sumaPila4 / contador;

        System.out.println("EJ F");
        System.out.println("El promedio de la pila es: " + promedio);

        scanner.close();
    }

}


